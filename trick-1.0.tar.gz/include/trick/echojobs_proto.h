#ifndef ECHOJOBS_PROTO_H
#define ECHOJOBS_PROTO_H


#ifdef __cplusplus
extern "C" {
#endif

int echo_jobs_on(void) ;
int echo_jobs_off(void) ;

#ifdef __cplusplus
}
#endif

#endif

