
#ifndef MASTER_PROTO_H
#define MASTER_PROTO_H

#ifdef __cplusplus
extern "C" {
#endif

    int ms_master_enable(void) ;
    int ms_master_disable(void) ;

#ifdef __cplusplus
}
#endif

#endif

