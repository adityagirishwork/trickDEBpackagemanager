/*
    PURPOSE:
        (All defined constant variables.)
*/

#ifndef TRICKCONSTANT_HH
#define TRICKCONSTANT_HH

#define TRICK_MAX_LONG_LONG 9223372036854775807LL

#endif
