
#ifndef CHECKPOINT_STL_PROTOS_HH
#define CHECKPOINT_STL_PROTOS_HH

#include <string>

// prototype of functions used in checkpoint_stl templates

std::string stl_type_name_convert(std::string in_type) ;

#endif
