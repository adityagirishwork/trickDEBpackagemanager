
#ifndef POPULATE_ATTRIBUTE_MAPS_HH
#define POPULATE_ATTRIBUTE_MAPS_HH

void populate_sim_services_class_map() ;
void populate_sim_services_enum_map() ;

void populate_class_map() ;
void populate_enum_map() ;

#endif
