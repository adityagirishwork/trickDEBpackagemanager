
#ifndef STLUTILITIES_HH
#define STLUTILITIES_HH

#include <string>

namespace Trick {

void delete_trick_stl( std::string object_name , unsigned int stl_id) ;
void delete_trick_map_stl( std::string obj_name , unsigned int stl_id ) ;

}

#endif
