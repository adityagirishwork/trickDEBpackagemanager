
#ifndef COLLECT_PROTO_HH
#define COLLECT_PROTO_HH

void ** add_collect( void ** collector , void * collectee ) ;
void ** delete_collect( void ** collector , void * collectee ) ;

#endif
