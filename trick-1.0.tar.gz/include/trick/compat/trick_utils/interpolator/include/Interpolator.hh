#include "trick/Interpolator.hh"
