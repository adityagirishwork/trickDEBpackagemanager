#include "trick/vector_macros.h"
