#include "trick/rand_generator.h"
