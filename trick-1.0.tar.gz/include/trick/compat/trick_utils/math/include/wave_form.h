#include "trick/wave_form.h"
