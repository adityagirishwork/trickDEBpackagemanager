#include "trick/quat_macros.h"
