#include "trick/lstack.h"
