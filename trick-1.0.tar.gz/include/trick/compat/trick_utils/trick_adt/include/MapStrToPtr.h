#include "trick/MapStrToPtr.h"
