#include "trick/lqueue.h"
