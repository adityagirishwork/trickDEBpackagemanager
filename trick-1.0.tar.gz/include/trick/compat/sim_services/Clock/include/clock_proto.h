#include "trick/clock_proto.h"
