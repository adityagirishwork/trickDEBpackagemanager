#include "trick/GetTimeOfDayClock.hh"
