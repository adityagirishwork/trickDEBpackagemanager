#include "trick/collect_macros.h"
