#include "trick/TrickConstant.hh"
