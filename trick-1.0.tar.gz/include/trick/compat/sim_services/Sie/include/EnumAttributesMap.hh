#include "trick/EnumAttributesMap.hh"
