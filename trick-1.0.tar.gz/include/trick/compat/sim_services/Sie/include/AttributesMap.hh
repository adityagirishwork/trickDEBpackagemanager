#include "trick/AttributesMap.hh"
