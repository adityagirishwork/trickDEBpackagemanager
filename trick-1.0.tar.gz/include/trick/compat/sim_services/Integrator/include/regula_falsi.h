#include "trick/regula_falsi.h"
