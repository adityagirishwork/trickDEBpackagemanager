#include "trick/JSONVariableServer.hh"
