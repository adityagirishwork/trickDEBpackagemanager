#include "trick/JSONVariableServerThread.hh"
