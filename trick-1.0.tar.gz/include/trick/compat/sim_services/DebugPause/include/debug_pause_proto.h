#include "trick/debug_pause_proto.h"
