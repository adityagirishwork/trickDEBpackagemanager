#pragma message ( "checkpoint_stack.hh has moved to trick/checkpoint_stack.hh" )
#include "trick/checkpoint_stack.hh"
