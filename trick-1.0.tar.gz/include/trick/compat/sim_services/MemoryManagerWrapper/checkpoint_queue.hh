#pragma message ( "checkpoint_queue.hh has moved to trick/checkpoint_queue.hh" )
#include "trick/checkpoint_queue.hh"
