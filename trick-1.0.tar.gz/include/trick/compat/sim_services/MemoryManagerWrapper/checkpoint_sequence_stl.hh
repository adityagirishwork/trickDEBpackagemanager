#pragma message ( "checkpoint_sequence_stl.hh has moved to trick/checkpoint_sequence_stl.hh" )
#include "trick/checkpoint_sequence_stl.hh"

