#pragma message ( "checkpoint_pair.hh has moved to trick/checkpoint_pair.hh" )
#include "trick/checkpoint_pair.hh"

