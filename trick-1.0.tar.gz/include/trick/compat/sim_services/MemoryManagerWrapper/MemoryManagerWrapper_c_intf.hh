#pragma message ( "MemoryManagerWrapper_c_intf.hh has moved to trick/CheckPointRestart_c_intf.hh" )
#include "trick/CheckPointRestart_c_intf.hh"
