#include "trick/MemoryManagerWrapper_c_intf.hh"
