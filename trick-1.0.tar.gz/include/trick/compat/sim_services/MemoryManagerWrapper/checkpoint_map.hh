#pragma message ( "checkpoint_map.hh has moved to trick/checkpoint_map.hh" )
#include "trick/checkpoint_map.hh"
