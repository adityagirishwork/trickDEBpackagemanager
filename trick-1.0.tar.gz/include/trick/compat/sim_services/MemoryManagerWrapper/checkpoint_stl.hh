#pragma message ( "checkpoint_stl.hh has moved to trick/checkpoint_stl.hh" )
#include "trick/checkpoint_stl.hh"

