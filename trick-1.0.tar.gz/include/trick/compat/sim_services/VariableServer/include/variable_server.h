#include "trick/variable_server.h"
