#include "trick/variable_server_proto.h"
