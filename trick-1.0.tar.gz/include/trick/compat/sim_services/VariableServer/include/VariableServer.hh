#include "trick/VariableServer.hh"
