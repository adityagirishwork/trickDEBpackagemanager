#include "trick/VariableServerReference.hh"
