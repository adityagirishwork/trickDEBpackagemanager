#include "trick/variable_server_message_types.h"
