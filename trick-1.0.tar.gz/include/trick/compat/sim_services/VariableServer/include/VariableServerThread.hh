#include "trick/VariableServerThread.hh"
