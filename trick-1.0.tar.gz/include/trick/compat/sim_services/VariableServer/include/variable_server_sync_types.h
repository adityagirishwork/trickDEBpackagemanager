#include "trick/variable_server_sync_types.h"
