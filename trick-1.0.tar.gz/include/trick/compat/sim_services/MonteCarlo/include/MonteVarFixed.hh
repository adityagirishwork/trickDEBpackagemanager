#include "trick/MonteVarFixed.hh"
