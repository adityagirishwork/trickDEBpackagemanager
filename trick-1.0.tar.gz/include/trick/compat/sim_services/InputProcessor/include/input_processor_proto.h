#include "trick/input_processor_proto.h"
