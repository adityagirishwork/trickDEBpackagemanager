#include "trick/ExternalApplication.hh"
