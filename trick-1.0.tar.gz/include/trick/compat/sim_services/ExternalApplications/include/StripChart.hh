#include "trick/StripChart.hh"
