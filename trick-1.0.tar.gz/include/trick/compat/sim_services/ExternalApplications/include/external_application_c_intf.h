#include "trick/external_application_c_intf.h"
