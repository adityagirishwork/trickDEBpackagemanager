#include "trick/MalfunctionsTrickView.hh"
