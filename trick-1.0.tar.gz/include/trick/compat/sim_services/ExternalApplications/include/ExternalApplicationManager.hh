#include "trick/ExternalApplicationManager.hh"
