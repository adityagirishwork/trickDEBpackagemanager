#include "trick/collect_proto.hh"
