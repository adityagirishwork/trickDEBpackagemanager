#include "trick/FrameDataRecordGroup.hh"
