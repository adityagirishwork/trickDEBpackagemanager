#include "trick/Message_proto.hh"
