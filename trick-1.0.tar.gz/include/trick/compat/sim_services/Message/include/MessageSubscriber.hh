#include "trick/MessageSubscriber.hh"
