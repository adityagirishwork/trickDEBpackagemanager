#include "trick/MessageCout.hh"
