#include "trick/StaticStructMember.hh"
