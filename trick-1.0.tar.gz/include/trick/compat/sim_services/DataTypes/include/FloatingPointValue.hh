#include "trick/FloatingPointValue.hh"
