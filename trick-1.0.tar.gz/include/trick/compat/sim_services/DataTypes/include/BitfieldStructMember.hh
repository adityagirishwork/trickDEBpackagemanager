#include "trick/BitfieldStructMember.hh"
