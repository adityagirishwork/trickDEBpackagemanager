#include "trick/EnumDictionary.hh"
