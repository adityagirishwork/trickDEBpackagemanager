#include "trick/Enumerator.hh"
