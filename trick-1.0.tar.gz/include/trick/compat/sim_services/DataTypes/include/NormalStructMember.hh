#include "trick/NormalStructMember.hh"
