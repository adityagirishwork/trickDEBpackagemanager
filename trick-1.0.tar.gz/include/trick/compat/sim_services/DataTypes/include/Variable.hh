#include "trick/Variable.hh"
