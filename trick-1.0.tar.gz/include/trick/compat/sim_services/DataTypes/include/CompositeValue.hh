#include "trick/CompositeValue.hh"
