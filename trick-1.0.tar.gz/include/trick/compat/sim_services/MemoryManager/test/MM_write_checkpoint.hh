#include "trick/MM_write_checkpoint.hh"
