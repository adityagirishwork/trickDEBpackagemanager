#include "trick/MM_get_enumerated.hh"
