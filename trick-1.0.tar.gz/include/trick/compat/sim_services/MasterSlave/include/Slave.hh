#include "trick/Slave.hh"
