#include "trick/Master.hh"
