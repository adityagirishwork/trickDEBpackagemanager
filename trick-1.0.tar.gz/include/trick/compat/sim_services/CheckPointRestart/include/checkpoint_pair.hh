#include "trick/checkpoint_pair.hh"
