#include "trick/checkpoint_stack.hh"
