#include "trick/ClassicCheckPointAgent.hh"
