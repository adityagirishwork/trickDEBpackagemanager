#include "trick/InstrumentBase.hh"
